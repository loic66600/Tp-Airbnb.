-- MySQL dump 10.13  Distrib 5.7.29, for Linux (x86_64)
--
-- Host: localhost    Database: data_base_airbnb
-- ------------------------------------------------------
-- Server version	5.7.29

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES UTF8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `address`
--

DROP TABLE IF EXISTS `address`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `address` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `address` varchar(255) DEFAULT NULL,
  `zip_code` int(11) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `country` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `address`
--

LOCK TABLES `address` WRITE;
/*!40000 ALTER TABLE `address` DISABLE KEYS */;
INSERT INTO `address` VALUES (1,'12 rue du paradis',66000,'Perpignan','France','0658673165'),(2,'13 rue du plaisir',66600,'Rivesaltes','France','0658613041'),(3,'12 rue du paradis',66000,'La Valette','Malte','0658673165'),(4,'14 avenue de Prades',66500,'Prades','France','0623252128'),(5,'route de Chambord',41000,'Chambord','France','0268516378'),(6,'1 avenue du cocotier',10200,'Port  Louis','Maurice','1836313235'),(7,NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `address` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `equipement`
--

DROP TABLE IF EXISTS `equipement`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `equipement` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `label` varchar(255) DEFAULT NULL,
  `category` varchar(255) DEFAULT NULL,
  `image_path` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=45 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `equipement`
--

LOCK TABLES `equipement` WRITE;
/*!40000 ALTER TABLE `equipement` DISABLE KEYS */;
INSERT INTO `equipement` VALUES (1,'Produits de nettoyage','Salle de bain','produit.svg'),(2,'Shampooing','Salle de bain','shampooing.svg'),(3,'Douche extérieure','Salle de bain','douche-ex.svg'),(4,'Eau chaude','Salle de bain','eau-chaude.svg'),(5,'Lave-linge','Chambre et linge','lave-linge.svg'),(6,'Draps','Chambre et linge','draps.svg'),(7,'Oreillers et couvertures supplémentaires','Chambre et linge','oreiller.svg'),(8,'Stores','Chambre et linge','store.svg'),(9,'Fer à repasser','Chambre et linge','fer.svg'),(10,'Étendoir à linge','Chambre et linge','etendoir.svg'),(11,'TV HD','Divertissement','tv.svg'),(12,'Système audio','Divertissement','audio.svg'),(13,'Lit pour bébé','Famille','lit-baby.svg'),(14,'Lit parapluie','Famille','lit-parapluie.svg'),(15,'Jouets et livres pour enfants','Famille','jouet.svg'),(16,'Baignoire pour bébés','Famille','baignoir-baby.svg'),(17,'Vaisselle pour enfants','Famille','vaisselle-baby.svg'),(18,'Caches-prises','Famille','cache-prise.svg'),(19,'Barrières de sécurité pour bébé','Famille','security-barriere.svg'),(20,'Climatisation centrale','Chauffage et climisation','clim.svg'),(21,'Chauffage central','Chauffage et climisation','chauffage.svg'),(22,'Wi-Fi','Internet et bureau','wifi.svg'),(23,'Espace de travail','Internet et bureau','bureau.svg'),(24,'Cuisine','Cuisine et salle à manger','cuisine.svg'),(25,'Réfrigérateur','Cuisine et salle à manger','frigo.svg'),(26,'Four à micro-ondes','Cuisine et salle à manger','microndes.svg'),(27,'Équipements de cuisine de base','Cuisine et salle à manger','ustensible.svg'),(28,'Vaisselle et couverts','Cuisine et salle à manger','vaisselle.svg'),(29,'Four','Cuisine et salle à manger','four.svg'),(30,'Bouilloire électrique','Cuisine et salle à manger','bouilloire.svg'),(31,'Cafetière','Cuisine et salle à manger','cafetiere.svg'),(32,'Grille-pain','Cuisine et salle à manger','grille-pain.svg'),(33,'Table à manger','Cuisine et salle à manger','table-manger.svg'),(34,'Plaque de cuisson','Cuisine et salle à manger','plaque.svg'),(35,'Entrée privée','Caractéristiques','entrer.svg'),(36,'Entrée public','Caractéristiques','entrer.svg'),(37,'Privé : patio ou balcon','Extérieur','balcon.svg'),(38,'Mobilier extérieur','Extérieur','mobilier.svg'),(39,'Espace repas en plein air','Extérieur','mobilier.svg'),(40,'Barbecue','Extérieur','barbecue.svg'),(41,'Vélos','Extérieur','velo.svg'),(42,'Chaises longues','Extérieur','chaise-longue.svg'),(43,'Parking privé (2 places)','Parking et installations','voiture.svg'),(44,'Parking gratuit dans la rue','Parking et installations','voiture.svg');
/*!40000 ALTER TABLE `equipement` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `logement`
--

DROP TABLE IF EXISTS `logement`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `logement` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `description` text,
  `price_per_night` float DEFAULT NULL,
  `nb_room` int(11) DEFAULT NULL,
  `nb_bed` int(11) DEFAULT NULL,
  `nb_bath` int(11) DEFAULT NULL,
  `nb_traveler` int(11) DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT NULL,
  `type_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `address_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `type_id` (`type_id`),
  KEY `user_id` (`user_id`),
  KEY `address_id` (`address_id`),
  CONSTRAINT `logement_ibfk_1` FOREIGN KEY (`type_id`) REFERENCES `type` (`id`),
  CONSTRAINT `logement_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`),
  CONSTRAINT `logement_ibfk_3` FOREIGN KEY (`address_id`) REFERENCES `address` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `logement`
--

LOCK TABLES `logement` WRITE;
/*!40000 ALTER TABLE `logement` DISABLE KEYS */;
INSERT INTO `logement` VALUES (1,'Maison','Maison avec piscine',92,1,1,1,2,1,1,2,1),(2,'Cabane','Cabane dans les arbres',86,1,1,1,1,1,2,2,2),(3,'Île','Maison en bord de falaise sur mon île',150,4,8,2,4,1,3,2,3),(4,'Moulin','Moulin moderne',90,1,1,1,1,1,4,2,4),(5,'Chateau','chateau d \'époque',200,4,6,1,8,1,6,2,5),(6,'paradis','paradis sur terre',75,1,1,1,2,1,5,2,6);
/*!40000 ALTER TABLE `logement` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `logementequipement`
--

DROP TABLE IF EXISTS `logementequipement`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `logementequipement` (
  `logement_id` int(11) NOT NULL,
  `equipement_id` int(11) NOT NULL,
  PRIMARY KEY (`logement_id`,`equipement_id`),
  KEY `equipement_id` (`equipement_id`),
  CONSTRAINT `logementequipement_ibfk_1` FOREIGN KEY (`logement_id`) REFERENCES `logement` (`id`),
  CONSTRAINT `logementequipement_ibfk_2` FOREIGN KEY (`equipement_id`) REFERENCES `equipement` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `logementequipement`
--

LOCK TABLES `logementequipement` WRITE;
/*!40000 ALTER TABLE `logementequipement` DISABLE KEYS */;
/*!40000 ALTER TABLE `logementequipement` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `media`
--

DROP TABLE IF EXISTS `media`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `media` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `label` varchar(255) DEFAULT NULL,
  `image_path` varchar(255) DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT NULL,
  `logement_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `logement_id` (`logement_id`),
  CONSTRAINT `media_ibfk_1` FOREIGN KEY (`logement_id`) REFERENCES `logement` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `media`
--

LOCK TABLES `media` WRITE;
/*!40000 ALTER TABLE `media` DISABLE KEYS */;
INSERT INTO `media` VALUES (1,'maison1','maison1.webp',1,1),(2,'cabane','cabane.webp',1,2),(3,'ile','maison_ile3.webp',1,3),(4,'moulin','moulin4.webp',1,4),(5,'chateau','chateau.webp',1,5),(6,'paradis','paradis.webp',1,6),(7,'interieur','interieur1.webp',1,1),(9,'salon','salon2.webp',1,2),(10,'cabane','vuecabane2.webp',1,2),(13,'lit','lit3.webp',1,3),(14,'vue','vue3.webp',1,3),(15,'vue','vue4.webp',1,4),(16,'douche','douche4.webp',1,4),(17,'vestige','vestige5.webp',1,5),(18,'gallerie','gallerie5.webp',1,5),(19,'lit','lit1.webp',1,1),(20,'vue','vue5.webp',1,6),(21,'fauteuil','fauteuille5.webp',1,6);
/*!40000 ALTER TABLE `media` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reservation`
--

DROP TABLE IF EXISTS `reservation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `reservation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_number` varchar(255) DEFAULT NULL,
  `date_start` date DEFAULT NULL,
  `date_end` date DEFAULT NULL,
  `nb_adult` int(11) DEFAULT NULL,
  `nb_child` int(11) DEFAULT NULL,
  `price_total` float DEFAULT NULL,
  `logement_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `logement_id` (`logement_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `reservation_ibfk_1` FOREIGN KEY (`logement_id`) REFERENCES `logement` (`id`),
  CONSTRAINT `reservation_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reservation`
--

LOCK TABLES `reservation` WRITE;
/*!40000 ALTER TABLE `reservation` DISABLE KEYS */;
INSERT INTO `reservation` VALUES (34,'FACT2406_1','2024-06-18','2024-06-23',2,1,1750,5,3);
/*!40000 ALTER TABLE `reservation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `type`
--

DROP TABLE IF EXISTS `type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `label` varchar(255) DEFAULT NULL,
  `image_path` varchar(255) DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `type`
--

LOCK TABLES `type` WRITE;
/*!40000 ALTER TABLE `type` DISABLE KEYS */;
INSERT INTO `type` VALUES (1,'maison','maison1.webp',1),(2,'cabane','cabane.webp',1),(3,'ile','maison_ile3',1),(4,'moulin','moulin4.webp',1),(5,'chateau','chateau.webp',1),(6,'ile de paradis','paradis.webp',1);
/*!40000 ALTER TABLE `type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `lastname` varchar(255) DEFAULT NULL,
  `firstname` varchar(255) DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT NULL,
  `address_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `address_id` (`address_id`),
  CONSTRAINT `user_ibfk_1` FOREIGN KEY (`address_id`) REFERENCES `address` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (2,'admin@admin.fr','$2y$10$MojYjG5JkzN.3W4cV8wEaOFG38J9/xC.3jOXn7sZeKjXNHHKbiUA6','Loic','Rossignol',1,2),(3,'admin2@admin.com','$2y$10$qQBeDqH0e8l1AfnsXsGgD.V693gFwkE9Gh.F8d.i4lurSUoDKdKQO','Rossignol','loic',1,3),(4,'loic.rossignol82@hotmail.fr','$2y$10$euH1eVSATDrxfEj.RK2TAeELYNXq7W2aliWyZmOAJTiJl5rkcz6jS','Rossignol','loic',1,7);
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-06-19 20:59:11
